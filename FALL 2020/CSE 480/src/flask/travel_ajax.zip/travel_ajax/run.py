from app import taj_app

taj_app.run(debug=True, port=80)