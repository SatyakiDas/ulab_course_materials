from flask import Flask

taj_app = Flask(__name__)

from app import views