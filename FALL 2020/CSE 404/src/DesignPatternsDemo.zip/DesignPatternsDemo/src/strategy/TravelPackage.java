package strategy;

public interface TravelPackage {

    public void transportStrategy();

    public void roomStrategy();

    public void foodStrategy();
}
